package com.sprink.api.model;

public enum  PortionSize {
  JUMBO,STANDARD,LITE,PREMIUM
}
