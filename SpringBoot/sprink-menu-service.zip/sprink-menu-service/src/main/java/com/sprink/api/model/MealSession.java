package com.sprink.api.model;

public enum MealSession {
LUNCH,DINNER
}
