package com.sprink.api.model;

public enum MenuItemType {
	
	VEG,NON_VEG

}
