package com.sprink.api.model;

public enum CuisineType {
  NORTH,SOUTH,SALAD,KETO
}
