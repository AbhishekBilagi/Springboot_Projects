package com.student.exception;

import lombok.Data;

@Data
public class ErrorInfo {
	
	private String msg;
	private Integer errorCode;

}
